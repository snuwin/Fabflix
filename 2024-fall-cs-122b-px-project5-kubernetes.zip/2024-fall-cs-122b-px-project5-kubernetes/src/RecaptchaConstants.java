public class RecaptchaConstants {

    public static final String SECRET_KEY ="6LdHnngqAAAAAPthJwIe6rL5EHCIbHzIZzHPQB36";

}